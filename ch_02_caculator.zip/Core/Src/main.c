/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* USER CODE BEGIN 2 */
  GPIO_TypeDef* SEG_GPIO_Port[8]={SEG0_GPIO_Port, SEG1_GPIO_Port, SEG2_GPIO_Port, SEG3_GPIO_Port, SEG4_GPIO_Port,
  		                            SEG5_GPIO_Port, SEG6_GPIO_Port, SEG7_GPIO_Port};
  uint16_t SEG_Pin[8] = {SEG0_Pin, SEG1_Pin, SEG2_Pin, SEG3_Pin, SEG4_Pin, SEG5_Pin, SEG6_Pin, SEG7_Pin};
  uint16_t code[10] = {0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f};
  void display(int num)
  {
  	for (int i = 0; i < 8; i++)
  	{
			if (code[num] & (1 << i))
			{
				HAL_GPIO_WritePin(SEG_GPIO_Port[i], SEG_Pin[i], GPIO_PIN_SET);
			}
			else
			{
				HAL_GPIO_WritePin(SEG_GPIO_Port[i], SEG_Pin[i], GPIO_PIN_RESET);
			}
  	}
  }

  void set_digit(int8_t which)
  {
  	HAL_GPIO_WritePin(DIG0_GPIO_Port, DIG0_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(DIG1_GPIO_Port, DIG1_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(DIG2_GPIO_Port, DIG2_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(DIG3_GPIO_Port, DIG3_Pin, GPIO_PIN_RESET);
  	switch(which)
  	{
  	  case 0: HAL_GPIO_WritePin(DIG0_GPIO_Port, DIG0_Pin, GPIO_PIN_SET); break;
  	  case 1: HAL_GPIO_WritePin(DIG1_GPIO_Port, DIG1_Pin, GPIO_PIN_SET); break;
  	  case 2: HAL_GPIO_WritePin(DIG2_GPIO_Port, DIG2_Pin, GPIO_PIN_SET); break;
  	  case 3: HAL_GPIO_WritePin(DIG3_GPIO_Port, DIG3_Pin, GPIO_PIN_SET); break;
  	  default:
  	  	HAL_GPIO_WritePin(DIG0_GPIO_Port, DIG0_Pin, GPIO_PIN_RESET);
  	  	HAL_GPIO_WritePin(DIG1_GPIO_Port, DIG1_Pin, GPIO_PIN_RESET);
  	  	HAL_GPIO_WritePin(DIG2_GPIO_Port, DIG2_Pin, GPIO_PIN_RESET);
  	  	HAL_GPIO_WritePin(DIG3_GPIO_Port, DIG3_Pin, GPIO_PIN_RESET);
  	}

  }

  uint8_t read_GPIO_state()
  {
  	uint8_t state = 0x00;
  	state |= (HAL_GPIO_ReadPin(KC0_GPIO_Port, KC0_Pin) << 0);
  	state |= (HAL_GPIO_ReadPin(KC1_GPIO_Port, KC1_Pin) << 1);
  	state |= (HAL_GPIO_ReadPin(KC2_GPIO_Port, KC2_Pin) << 2);
  	state |= (HAL_GPIO_ReadPin(SEG0_GPIO_Port, SEG0_Pin) << 3);
  	state |= (HAL_GPIO_ReadPin(SEG1_GPIO_Port, SEG1_Pin) << 4);
  	state |= (HAL_GPIO_ReadPin(SEG2_GPIO_Port, SEG2_Pin) << 5);
  	state |= (HAL_GPIO_ReadPin(SEG3_GPIO_Port, SEG3_Pin) << 6);
  	state |= (HAL_GPIO_ReadPin(SEG4_GPIO_Port, SEG4_Pin) << 7);
  	return state;
  }

  void set_GPIO_state(uint8_t set_state)
  {
  	HAL_GPIO_WritePin(SEG0_GPIO_Port, SEG0_Pin, (set_state & 0x08)? GPIO_PIN_SET : GPIO_PIN_RESET);
  	HAL_GPIO_WritePin(SEG1_GPIO_Port, SEG1_Pin, (set_state & 0x10)? GPIO_PIN_SET : GPIO_PIN_RESET);
  	HAL_GPIO_WritePin(SEG2_GPIO_Port, SEG2_Pin, (set_state & 0x20)? GPIO_PIN_SET : GPIO_PIN_RESET);
  	HAL_GPIO_WritePin(SEG3_GPIO_Port, SEG3_Pin, (set_state & 0x40)? GPIO_PIN_SET : GPIO_PIN_RESET);
  	HAL_GPIO_WritePin(SEG4_GPIO_Port, SEG4_Pin, (set_state & 0x80)? GPIO_PIN_SET : GPIO_PIN_RESET);
  }

  uint8_t key_scan()
  {
  	uint8_t key_value;
  	set_digit(-1);
  	// scan the first row
  	set_GPIO_state(0x08);
  	if(read_GPIO_state() != 0x08)
  	{
  		HAL_Delay(0);
  		if(read_GPIO_state() != 0x08)
  		{
  			key_value = read_GPIO_state();
  			while(read_GPIO_state() != 0x08);
  			set_GPIO_state(0x00);
  			return key_value;
  		}
  	}

  	set_GPIO_state(0x10);
  	if(read_GPIO_state() != 0x10)
  	{
  		HAL_Delay(0);
  		if(read_GPIO_state() != 0x10)
  		{
  			key_value = read_GPIO_state();
  			while(read_GPIO_state() != 0x10);
  			set_GPIO_state(0x00);
  			return key_value;
  		}
  	}

  	set_GPIO_state(0x20);
  	if(read_GPIO_state() != 0x20)
  	{
  		HAL_Delay(0);
  		if(read_GPIO_state() != 0x20)
  		{
  			key_value = read_GPIO_state();
  			while(read_GPIO_state() != 0x20);
  			set_GPIO_state(0x00);
  			return key_value;
  		}
  	}

  	set_GPIO_state(0x40);
  	if(read_GPIO_state() != 0x40)
  	{
  		HAL_Delay(0);
  		if(read_GPIO_state() != 0x40)
  		{
  			key_value = read_GPIO_state();
  			while(read_GPIO_state() != 0x40);
  			set_GPIO_state(0x00);
  			return key_value;
  		}
  	}

  	set_GPIO_state(0x80);
  	if(read_GPIO_state() != 0x80)
  	{
  		HAL_Delay(0);
  		if(read_GPIO_state() != 0x80)
  		{
  			key_value = read_GPIO_state();
  			while(read_GPIO_state() != 0x80);
  			set_GPIO_state(0x00);
  			return key_value;
  		}
  	}
  	set_GPIO_state(0x00);
  	return 0xFF;
  }

  char key_decoder(uint8_t key_value)
  {
  	switch(key_value)
  	{
  	  case 0x09: return '1';
  	  case 0x0A: return '2';
  	  case 0x0C: return '3';
  	  case 0x11: return '4';
  	  case 0x12: return '5';
  	  case 0x14: return '6';
  	  case 0x21: return '7';
  	  case 0x22: return '8';
  	  case 0x24: return '9';
  	  case 0x41: return 'R';
  	  case 0x42: return '0';
  	  case 0x44: return '=';
  	  case 0x81: return '+';
  	  case 0x82: return '-';
  	  case 0x84: return '*';
  	  default : return '0';
  	}
  }

  uint8_t key_encoder(uint8_t real_key)
  {
  	switch(real_key)
  	{
  	case 1: return 0x09;
  	case 2: return 0x0A;
  	case 3: return 0x0C;
  	case 4: return 0x11;
  	case 5: return 0x12;
  	case 6: return 0x14;
  	case 7: return 0x21;
  	case 8: return 0x22;
  	case 9: return 0x24;
  	case 0: return 0x42;
  	}
  }

  uint8_t digits[4] = {0xFF,0xFF,0xFF,0xFF};
  int num1 = 10000, num2 = 10000;
  char operator = '0';
  int current_digit = 0;

  void display_all_digits()
  {
  	for(int i = 0; i < current_digit; i++)
  	{
  		set_digit(-1);
  		display(key_decoder(digits[current_digit-1-i])-'0');
  		set_digit(current_digit-1-i);
  		HAL_Delay(3);
  	}
  }

  void update_digits(uint8_t key_value)
  {
  	if(current_digit < 4)
  	{
  		for(int i = current_digit-1; i >= 0; i--)
  		{
  			digits[i+1] = digits[i];
  		}
  		digits[0] = key_value;
  		current_digit+=1;
  	}
  }

  void reset()
  {
  	for(int i = 0; i < 4; i++)
  	{
  		digits[i]=0xFF;
  	}
  	current_digit = 0;
  	for (int i = 0; i < 8; i++)
  	{
  	  HAL_GPIO_WritePin(SEG_GPIO_Port[i], SEG_Pin[i], GPIO_PIN_RESET);
  	}
  	set_digit(-1);
  }

  void save_num()
  {
  	int temp = 0;
  	for(int i = 0; i < current_digit; i++)
  	{
  		temp += (key_decoder(digits[i])-'0') * (int)pow(10,i);
  	}
  	if(num1 == 10000)
  	{
  		num1 = temp;
  	}
  	else
  	{
  		num2 = temp;
  	}
  }

  void result_to_digits(int result)
  {
  	int i = 0;
  	while(result/(int)pow(10,i) != 0)
  	{
  		i++;
  	}
  	current_digit = i;
  	for(int j = 0; j < 4; j++)
  	{
  		digits[j] = 0xFF;
  	}
  	for(int k = 0; k < current_digit; k++)
  	{
  		digits[k] = key_encoder(result % 10);
  		result /= 10;
  	}
  }

  void calculate()
  {
  	int result;
  	if(num1==10000 && num2==10000 && operator=='0')
  		return;
  	if(num1!=10000 && num2==10000 && operator=='0')
  		return;
  	switch(operator)
  	{
  	case '+':
  		result = num1+num2;
  		break;
  	case '-':
  		result = num1 - num2;
  		break;
  	case '*':
  		result = num1 * num2;
  		break;
  	default:
  		return;
  	}
  	num1=10000; num2=10000; operator='0';
  	result_to_digits(result);
  }

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  	uint8_t key_value = key_scan();
  	if(key_value != 0xFF)
  	{
  		switch (key_value)
  		{
  		  case 0x41:
  		  	reset();
  		  	break;
  		  case 0x44:
  		  	save_num();
  		  	calculate();
  		  	break;
  		  case 0x81:
  		  	save_num();
  		  	operator = key_decoder(0x81);
  		  	reset();
  		  	break;
  		  case 0x82:
  		  	save_num();
  		  	operator = key_decoder(0x82);
  		  	reset();
  		  	break;
  		  case 0x84:
  		  	save_num();
  		  	operator = key_decoder(0x84);
  		  	reset();
  		  	break;
  		  default:
  		  	update_digits(key_value);
  		  	break;
  		}

  	}
   display_all_digits();
  }

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, SEG2_Pin|SEG3_Pin|SEG4_Pin|SEG5_Pin
                          |SEG6_Pin|SEG7_Pin|SEG0_Pin|SEG1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, DIG0_Pin|DIG1_Pin|DIG2_Pin|DIG3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : SEG2_Pin SEG3_Pin SEG4_Pin SEG5_Pin
                           SEG6_Pin SEG7_Pin SEG0_Pin SEG1_Pin */
  GPIO_InitStruct.Pin = SEG2_Pin|SEG3_Pin|SEG4_Pin|SEG5_Pin
                          |SEG6_Pin|SEG7_Pin|SEG0_Pin|SEG1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : DIG0_Pin DIG1_Pin DIG2_Pin DIG3_Pin */
  GPIO_InitStruct.Pin = DIG0_Pin|DIG1_Pin|DIG2_Pin|DIG3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : KC0_Pin KC1_Pin */
  GPIO_InitStruct.Pin = KC0_Pin|KC1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : KC2_Pin */
  GPIO_InitStruct.Pin = KC2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(KC2_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
